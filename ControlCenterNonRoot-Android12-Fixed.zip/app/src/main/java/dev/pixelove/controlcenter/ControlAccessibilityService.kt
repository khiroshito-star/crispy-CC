package dev.pixelove.controlcenter

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.content.ComponentName
import android.provider.Settings.Panel

class ControlAccessibilityService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null
    private var torch = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onServiceConnected() { super.onServiceConnected(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; showHandle() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { }
    override fun onDestroy() { removePanel(); removeHandle(); super.onDestroy() }

    private fun params(w: Int, h: Int, gravity: Int = Gravity.TOP or Gravity.END) = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { this.gravity=gravity }
    private fun showHandle() {
        if (handle != null) return
        val v = TextView(this).apply { text="⌃"; textSize=23f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(0xff5359a8.toInt()); elevation=dp(8).toFloat() }
        val p=params(dp(54), dp(54)).apply { y=dp(220); x=dp(8) }
        var sx=0f; var sy=0f; var ox=0; var oy=0
        v.setOnTouchListener { _, e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; true }
                MotionEvent.ACTION_MOVE -> { p.x=(ox + sx-e.rawX).toInt().coerceAtLeast(0); p.y=(oy + e.rawY-sy).toInt().coerceAtLeast(0); wm.updateViewLayout(v,p); true }
                MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-sx)<12 && kotlin.math.abs(e.rawY-sy)<12) togglePanel(); true }
                else -> true
            }
        }
        handle=v; wm.addView(v,p)
    }
    private fun removeHandle() { handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }; handle=null }
    private fun removePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null }
    private fun togglePanel() { if (panel == null) showPanel() else removePanel() }
    private fun label(s: String, size: Float=14f, color: Int=Color.WHITE) = TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(dp(12),dp(9),dp(12),dp(9)) }
    private fun actionTile(title: String, subtitle: String?=null, action: () -> Unit): View = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(6),dp(4),dp(6),dp(4)); setBackgroundColor(0xff30323d.toInt())
        addView(label(title,15f)); if (subtitle!=null) addView(label(subtitle,11f,0xffc4c6d0.toInt()))
        setOnClickListener { action() }
    }
    private fun showPanel() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(16)); setBackgroundColor(0xee171923.toInt()); elevation=dp(18).toFloat() }
        val head=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; orientation=LinearLayout.HORIZONTAL }
        head.addView(label("Control Center",22f), LinearLayout.LayoutParams(0,-2,1f))
        head.addView(TextView(this).apply { text="✕"; textSize=20f; setTextColor(Color.WHITE); setPadding(dp(12),dp(8),dp(8),dp(8)); setOnClickListener { removePanel() } })
        root.addView(head)
        val grid=android.widget.GridLayout(this).apply { columnCount=2; useDefaultMargins=true }
        fun add(title:String, sub:String?=null, fn:()->Unit) { val v=actionTile(title,sub,fn); grid.addView(v, android.widget.GridLayout.LayoutParams().apply { width=0; height=dp(76); columnSpec=android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED,1f); setMargins(dp(4),dp(4),dp(4),dp(4)) }) }
        add("Wi-Fi", "Open network controls") { openPanelOrSettings(Settings.Panel.ACTION_INTERNET_CONNECTIVITY, Settings.ACTION_WIFI_SETTINGS) }
        add("Bluetooth", "Open Bluetooth settings") { startSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }
        add("Airplane mode", "Android system settings") { startSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }
        add("Do Not Disturb", "Sound & interruption") { openDnd() }
        add("Flashlight", if(torch) "On" else "Off") { toggleTorch() }
        add("Auto-rotate", "Display settings") { startSettings(Settings.ACTION_DISPLAY_SETTINGS) }
        add("Battery", "Battery settings") { startSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
        add("Screenshot", "Capture current screen") { val ok=performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT); if(!ok) toast("Screenshot unavailable") }
        add("Home", "Go to home screen") { performGlobalAction(GLOBAL_ACTION_HOME); removePanel() }
        add("Back", "Go back") { performGlobalAction(GLOBAL_ACTION_BACK); removePanel() }
        add("Recent apps", "Overview") { performGlobalAction(GLOBAL_ACTION_RECENTS); removePanel() }
        root.addView(grid)
        root.addView(label("Brightness",15f))
        val seek=SeekBar(this).apply { max=255; progress=try { Settings.System.getInt(contentResolver,Settings.System.SCREEN_BRIGHTNESS) } catch (_:Exception) { 128 } }
        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?, value:Int, user:Boolean) { if(user && Settings.System.canWrite(this@ControlAccessibilityService)) try { Settings.System.putInt(contentResolver,Settings.System.SCREEN_BRIGHTNESS,value.coerceAtLeast(1)) } catch (_:Exception) {} }
            override fun onStartTrackingTouch(s:SeekBar?) {}
            override fun onStopTrackingTouch(s:SeekBar?) { if(!Settings.System.canWrite(this@ControlAccessibilityService)) toast("Grant Modify system settings in the app first") }
        })
        root.addView(seek)
        root.addView(label("Volume",15f))
        val audio=getSystemService(AUDIO_SERVICE) as AudioManager
        val vol=SeekBar(this).apply { max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC); progress=audio.getStreamVolume(AudioManager.STREAM_MUSIC) }
        vol.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,v:Int,user:Boolean){if(user)audio.setStreamVolume(AudioManager.STREAM_MUSIC,v,0)}; override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){} })
        root.addView(vol)
        root.addView(label("Some protected switches open Android settings instead of silently changing system state.",11f,0xffb9bbc7.toInt()))
        panel=root
        val p=params(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { y=dp(30); flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN }
        try { wm.addView(root,p) } catch (_:Exception) { panel=null; toast("Could not display panel") }
    }
    private fun startSettings(action:String) { try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_:Exception) { toast("This settings page is unavailable") } }
    private fun openPanelOrSettings(panelAction:String, fallback:String) { try { startActivity(Intent(panelAction).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_:Exception) { startSettings(fallback) } }
    private fun openDnd() { try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_:Exception) { startSettings(Settings.ACTION_SOUND_SETTINGS) } }
    private fun toggleTorch() {
        try {
            val cm=getSystemService(CAMERA_SERVICE) as CameraManager
            val id=cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)==true }
            if(id==null) { toast("No flashlight found"); return }
            torch=!torch; cm.setTorchMode(id,torch)
        } catch (_:SecurityException) { toast("Camera permission is required") } catch (_:Exception) { toast("Flashlight could not be changed") }
    }
}
